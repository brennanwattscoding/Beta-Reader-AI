const METRICS = [
  { id: 'clarity', title: 'Easy to Understand', lowLabel: 'Horribly confusing', highLabel: 'Easy to Understand', subjective: false, includeInOverall: true, description: 'How easy the prose is to follow.' },
  { id: 'pacing', title: 'Perfect Pace', lowLabel: 'Terrible Pace', highLabel: 'Perfect Pace', subjective: false, includeInOverall: true, description: 'How well scenes move and escalate.' },
  { id: 'characters', title: 'Well Written Characters', lowLabel: 'Uninteresting Characters', highLabel: 'Well Written Characters', subjective: true, includeInOverall: false, description: 'How strongly distinct characters and agency appear on the page.' },
  { id: 'creativity', title: 'Very Creative', lowLabel: 'Cliché', highLabel: 'Very Creative', subjective: true, includeInOverall: false, description: 'How fresh the language and situations feel.' },
  { id: 'dialogue', title: 'Natural and Engaging Dialogue', lowLabel: 'Awkward Dialogue', highLabel: 'Natural and Engaging Dialogue', subjective: true, includeInOverall: false, description: 'How readable and believable the dialogue feels.' },
  { id: 'plot', title: 'Strong Plot', lowLabel: 'Weak Plot', highLabel: 'Strong Plot', subjective: false, includeInOverall: true, description: 'How much causality, conflict, and momentum are visible.' },
  { id: 'setting', title: 'Vivid and Immersive Setting', lowLabel: 'Flat Setting', highLabel: 'Vivid and Immersive Setting', subjective: false, includeInOverall: true, description: 'How grounded the environment feels.' },
  { id: 'grammar', title: 'Excellent Grammar & Style', lowLabel: 'Poor Grammar & Style', highLabel: 'Excellent Grammar & Style', subjective: false, includeInOverall: true, description: 'How mechanically clean the prose appears.' },
  { id: 'opening', title: 'Hooking Opening', lowLabel: 'Boring Start', highLabel: 'Hooking Opening', subjective: false, includeInOverall: true, description: 'How strong the opening pull feels.' },
  { id: 'twists', title: 'Surprising Twists', lowLabel: 'Predictable Twists', highLabel: 'Surprising Twists', subjective: true, includeInOverall: false, description: 'A rough estimate of how expected or surprising turns feel.' },
  { id: 'themes', title: 'Deep and Thought-Provoking Themes', lowLabel: 'Shallow Themes', highLabel: 'Deep and Thought-Provoking Themes', subjective: true, includeInOverall: false, description: 'How much larger idea / motif language recurs.' },
  { id: 'emotion', title: 'Heart-Wrenching or Moving', lowLabel: 'Weak Emotional Impact', highLabel: 'Heart-Wrenching or Moving', subjective: true, includeInOverall: false, description: 'How emotionally charged the writing appears.' },
  { id: 'inCharacter', title: 'Consistently In Character', lowLabel: 'Always out of Character', highLabel: 'Consistently In Character', subjective: true, includeInOverall: false, description: 'A rough estimate of whether speech patterns stay stable.' },
];

const SUBJECTIVE_IDS = METRICS.filter((m) => m.subjective).map((m) => m.id);

const DRAFT_WEIGHTS = {
  first: { clarity: 1.28, pacing: 1.08, characters: 0.95, creativity: 0.9, dialogue: 0.92, plot: 1.34, setting: 0.95, grammar: 0.7, opening: 1.15, twists: 0.72, themes: 0.72, emotion: 0.78, inCharacter: 0.84 },
  middle: { clarity: 1.1, pacing: 1.1, characters: 1.02, creativity: 1.0, dialogue: 1.0, plot: 1.18, setting: 1.0, grammar: 0.95, opening: 1.04, twists: 0.9, themes: 0.9, emotion: 0.96, inCharacter: 0.96 },
  final: { clarity: 1.04, pacing: 1.14, characters: 1.1, creativity: 1.0, dialogue: 1.15, plot: 1.08, setting: 1.04, grammar: 1.35, opening: 1.0, twists: 1.0, themes: 1.0, emotion: 1.1, inCharacter: 1.14 },
};

const GENRE_BIASES = {
  general: { setting: 1.0, opening: 1.0, pacing: 1.0, twists: 1.0, emotion: 1.0, dialogue: 1.0, plot: 1.0 },
  fantasy: { setting: 1.12, creativity: 1.08, plot: 1.0, dialogue: 0.98, opening: 1.0 },
  scifi: { setting: 1.08, creativity: 1.08, clarity: 1.05, plot: 1.0, opening: 0.98 },
  romance: { dialogue: 1.12, emotion: 1.14, characters: 1.12, setting: 0.92, twists: 0.9 },
  thriller: { plot: 1.15, pacing: 1.16, opening: 1.12, twists: 1.15, emotion: 0.96 },
  horror: { pacing: 1.08, setting: 1.06, emotion: 1.08, opening: 1.05, plot: 1.06 },
  historical: { setting: 1.12, clarity: 1.04, characters: 1.02, pacing: 0.96 },
  contemporary: { dialogue: 1.06, characters: 1.08, setting: 0.96, pacing: 1.02 },
  nonfiction: { clarity: 1.18, plot: 0.94, setting: 0.9, themes: 1.02, creativity: 0.9 },
};

const AUDIENCE_THRESHOLDS = {
  mg: { targetSentence: 16, targetWord: 4.9, openingBoost: 1.08, clarityBoost: 1.12 },
  ya: { targetSentence: 18, targetWord: 5.1, openingBoost: 1.05, clarityBoost: 1.06 },
  na: { targetSentence: 20, targetWord: 5.35, openingBoost: 1.0, clarityBoost: 1.0 },
  adult: { targetSentence: 22, targetWord: 5.55, openingBoost: 0.98, clarityBoost: 0.98 },
};

const DIALOGUE_ATTRIBUTION = ['said', 'asked', 'replied', 'murmured', 'whispered', 'snapped', 'shouted', 'yelled', 'answered', 'called', 'sighed', 'breathed', 'growled'];
const SENSORY_WORDS = ['cold', 'warm', 'sharp', 'rough', 'smooth', 'bright', 'dark', 'glow', 'smell', 'scent', 'odor', 'taste', 'sound', 'echo', 'whisper', 'rain', 'wind', 'dust', 'stone', 'wood', 'metal', 'light', 'shadow', 'salt', 'blood', 'velvet', 'smoke', 'fog', 'heat', 'ice', 'mud', 'glass', 'thunder', 'lantern', 'sunlight', 'starlight'];
const EMOTION_WORDS = ['afraid', 'angry', 'furious', 'hurt', 'grief', 'grieving', 'sad', 'joy', 'delight', 'hope', 'hopeless', 'love', 'hate', 'relief', 'shame', 'guilt', 'lonely', 'terror', 'panic', 'regret', 'tender', 'cry', 'sob', 'laugh', 'tremble', 'aching', 'fear', 'desperate', 'mourn', 'heart'];
const ABSTRACT_WORDS = ['freedom', 'justice', 'memory', 'faith', 'identity', 'truth', 'power', 'loss', 'forgiveness', 'duty', 'mercy', 'belonging', 'legacy', 'grace', 'hope', 'violence', 'love', 'control', 'betrayal', 'honor', 'purpose', 'shame', 'responsibility'];
const CONFLICT_WORDS = ['fight', 'argue', 'refuse', 'risk', 'danger', 'threat', 'escape', 'fail', 'chase', 'hide', 'betray', 'lose', 'attack', 'crash', 'fall', 'bleed', 'warn', 'suspect', 'expose', 'kill', 'discover', 'confront'];
const ACTION_WORDS = ['run', 'jump', 'grab', 'open', 'slam', 'pull', 'push', 'climb', 'race', 'threw', 'strike', 'duck', 'turned', 'rush', 'stumble', 'dashed', 'caught'];
const SETTING_WORDS = ['street', 'hall', 'forest', 'castle', 'room', 'door', 'window', 'mountain', 'ship', 'car', 'station', 'kitchen', 'field', 'sky', 'river', 'sea', 'hallway', 'bedroom', 'market', 'city', 'village', 'camp', 'tower', 'office'];
const FILLER_PHRASES = ['began to', 'started to', 'seemed to', 'felt like', 'in order to', 'there was', 'there were', 'it was then that'];
const CLICHE_PHRASES = ['heart skipped a beat', 'let out a breath', 'little did he know', 'little did she know', 'only time will tell', 'cold as ice', 'burning with desire', 'all hell broke loose', 'at the end of the day', 'dead as a doornail', 'the calm before the storm', 'eyes widened'];
const EXPOSITION_PHRASES = ['as you know', 'remember when', 'for years', 'had always', 'used to', 'back when', 'once upon a time'];
const SURPRISE_MARKERS = ['suddenly', 'unexpectedly', 'but then', 'however', 'instead', 'revealed', 'turned out', 'to his surprise', 'to her surprise'];
const FILTER_WORDS = ['saw', 'seen', 'watched', 'noticed', 'realized', 'felt', 'thought', 'wondered', 'heard', 'looked', 'seemed'];
const WEAK_NARRATION_PHRASES = ['there was', 'there were', 'it seemed', 'it felt', 'she saw', 'he saw', 'she noticed', 'he noticed'];
const SCENE_TRANSITION_MARKERS = ['then', 'later', 'meanwhile', 'after a moment', 'moments later', 'soon', 'eventually'];
const TELLING_WORDS = ['knew', 'realized', 'understood', 'remembered', 'felt', 'wondered'];
const STOP_CAPITALIZED = new Set(['The', 'A', 'An', 'I', 'He', 'She', 'They', 'We', 'It', 'That', 'Then', 'When', 'But', 'And', 'If', 'Because', 'However', 'Chapter', 'Prologue', 'Epilogue', 'Part', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']);
const CHARACTER_TITLES = new Set(['Mr', 'Mrs', 'Ms', 'Miss', 'Mx', 'Dr', 'Professor', 'Prof', 'Captain', 'Capt', 'Sir', 'Lady', 'Lord', 'King', 'Queen', 'Prince', 'Princess']);
const GENRE_SIGNAL_WORDS = {
  general: [],
  fantasy: ['kingdom', 'sword', 'throne', 'magic', 'spell', 'dragon', 'temple', 'oracle', 'curse', 'realm', 'banner', 'heir'],
  scifi: ['ship', 'station', 'orbit', 'engine', 'circuit', 'signal', 'quantum', 'module', 'android', 'protocol', 'reactor', 'colony'],
  romance: ['kiss', 'touch', 'desire', 'heart', 'ache', 'yearning', 'beloved', 'chemistry', 'longing', 'tender'],
  thriller: ['clue', 'suspect', 'evidence', 'alibi', 'shadow', 'locked', 'blood', 'chase', 'threat', 'coverup', 'motive'],
  horror: ['shadow', 'grave', 'whisper', 'scream', 'rot', 'haunt', 'curse', 'darkness', 'teeth', 'basement', 'ritual'],
  historical: ['regiment', 'carriage', 'estate', 'telegram', 'parlor', 'duke', 'countess', 'empire', 'harbor', 'uniform', 'manor'],
  contemporary: ['apartment', 'texted', 'parking', 'kitchen', 'school', 'office', 'highway', 'phone', 'coffee', 'train'],
  nonfiction: ['research', 'history', 'evidence', 'documented', 'archive', 'study', 'analysis', 'record', 'source', 'policy'],
};

const els = {
  fileInput: document.getElementById('fileInput'),
  genreSelect: document.getElementById('genreSelect'),
  audienceSelect: document.getElementById('audienceSelect'),
  draftStageSelect: document.getElementById('draftStageSelect'),
  completionRange: document.getElementById('completionRange'),
  completionValue: document.getElementById('completionValue'),
  analyzeBtn: document.getElementById('analyzeBtn'),
  loadSampleBtn: document.getElementById('loadSampleBtn'),
  statusBox: document.getElementById('statusBox'),
  summaryCards: document.getElementById('summaryCards'),
  overallBars: document.getElementById('overallBars'),
  heatmapWrap: document.getElementById('heatmapWrap'),
  trendMetricSelect: document.getElementById('trendMetricSelect'),
  trendChart: document.getElementById('trendChart'),
  findingsTitle: document.getElementById('findingsTitle'),
  findingsSubtitle: document.getElementById('findingsSubtitle'),
  findingsMeta: document.getElementById('findingsMeta'),
  highlightList: document.getElementById('highlightList'),
  manuscriptMeta: document.getElementById('manuscriptMeta'),
  manuscriptView: document.getElementById('manuscriptView'),
};

const state = { analysis: null, manuscriptText: '', selectedMetricId: 'clarity', selectedChapterIndex: null, sourceName: '' };

function init() {
  els.completionRange.addEventListener('input', () => { els.completionValue.textContent = `${els.completionRange.value}%`; });
  els.analyzeBtn.addEventListener('click', handleAnalyze);
  els.loadSampleBtn.addEventListener('click', () => loadSample());
  els.trendMetricSelect.addEventListener('change', () => {
    state.selectedMetricId = els.trendMetricSelect.value;
    state.selectedChapterIndex = null;
    renderAll();
  });
  METRICS.forEach((metric) => {
    const option = document.createElement('option');
    option.value = metric.id;
    option.textContent = metric.title;
    els.trendMetricSelect.appendChild(option);
  });
  els.trendMetricSelect.value = state.selectedMetricId;
}

async function handleAnalyze() {
  const file = els.fileInput.files?.[0];
  if (!file) {
    setStatus('Select a .txt or .docx file first.', 'error');
    return;
  }
  await analyzeSource({ file, sourceName: file.name });
}

async function loadSample() {
  await analyzeSource({ text: getSampleManuscript(), sourceName: 'sample-manuscript.txt' });
}

async function analyzeSource({ file, text, sourceName }) {
  try {
    setWorking(true);
    setStatus('Reading manuscript locally…', 'working');
    const manuscriptText = text ?? await readDocumentText(file);
    if (!manuscriptText || manuscriptText.trim().length < 300) throw new Error('The manuscript was too short to analyze. Add more text or try a more complete sample.');
    await nextFrame();
    setStatus('Detecting chapters and building local craft signals…', 'working');
    const config = getConfig();
    const analysis = analyzeManuscript(manuscriptText, config, sourceName);
    state.analysis = analysis;
    state.manuscriptText = manuscriptText;
    state.sourceName = sourceName;
    state.selectedChapterIndex = null;
    els.trendMetricSelect.value = state.selectedMetricId;
    renderAll();
    setStatus(`Analysis ready. ${analysis.chapters.length} chapter${analysis.chapters.length === 1 ? '' : 's'} indexed locally.`, 'ready');
  } catch (error) {
    console.error(error);
    setStatus(error.message || 'Unable to analyze this file.', 'error');
  } finally {
    setWorking(false);
  }
}

function getConfig() {
  return { genre: els.genreSelect.value, audience: els.audienceSelect.value, draftStage: els.draftStageSelect.value, completion: Number(els.completionRange.value) };
}

async function readDocumentText(file) {
  const name = file.name.toLowerCase();
  if (name.endsWith('.txt')) return await file.text();
  if (name.endsWith('.docx')) {
    if (!window.JSZip?.loadAsync) throw new Error('The local .docx reader did not load. Keep libs/jszip.min.js next to index.html and try again.');
    const arrayBuffer = await file.arrayBuffer();
    return await extractDocxTextLocal(arrayBuffer);
  }
  throw new Error('Unsupported file type. Use .txt or .docx.');
}

async function extractDocxTextLocal(arrayBuffer) {
  const zip = await window.JSZip.loadAsync(arrayBuffer);
  const documentFile = zip.file('word/document.xml');
  if (!documentFile) throw new Error('This .docx file is missing word/document.xml, so it could not be read locally.');
  const xmlText = await documentFile.async('string');
  const parser = new DOMParser();
  const xml = parser.parseFromString(xmlText, 'application/xml');
  if (xml.querySelector('parsererror')) throw new Error('The .docx XML could not be parsed locally.');
  const paragraphs = [...xml.getElementsByTagNameNS('*', 'p')]
    .map((node) => flattenDocxParagraphText(node))
    .map((value) => value.replace(/\u00A0/g, ' ').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim())
    .filter(Boolean);
  if (!paragraphs.length) throw new Error('No readable paragraph text was found inside this .docx file.');
  return paragraphs.join('\n\n');
}

function flattenDocxParagraphText(node) {
  const parts = [];
  const walk = (current) => {
    [...current.childNodes].forEach((child) => {
      const name = child.localName || '';
      if (name === 't') {
        parts.push(child.textContent || '');
        return;
      }
      if (name === 'tab') {
        parts.push('\t');
        return;
      }
      if (name === 'br' || name === 'cr') {
        parts.push('\n');
        return;
      }
      walk(child);
    });
  };
  walk(node);
  return parts.join('');
}

function analyzeManuscript(inputText, config, sourceName) {
  const text = normalizeText(inputText);
  const chapterSeeds = splitIntoChapters(text);
  const global = buildGlobalContext(chapterSeeds, config);
  const chapters = chapterSeeds.map((seed, index) => analyzeChapter(seed, index, chapterSeeds.length, global));
  const overall = aggregateOverall(chapters, global, config);
  return { sourceName, config, chapters, overall, global };
}

function normalizeText(text) {
  return String(text || '').replace(/\r\n/g, '\n').replace(/\u00A0/g, ' ').replace(/\t/g, '  ').replace(/\n{3,}/g, '\n\n').trim();
}

function splitIntoChapters(text) {
  const lines = text.split('\n');
  const chapters = [];
  let currentTitle = 'Opening Section';
  let currentLines = [];
  const flush = () => {
    const body = currentLines.join('\n').trim();
    if (!body) return;
    const paragraphs = body.split(/\n\s*\n+/).map((p) => p.trim()).filter(Boolean);
    chapters.push({ title: normalizeHeading(currentTitle || `Chapter ${chapters.length + 1}`), text: body, paragraphs });
  };

  for (let i = 0; i < lines.length; i += 1) {
    const heading = detectChapterHeading(lines, i);
    if (heading) {
      if (currentLines.join('').trim().length > 160) {
        flush();
        currentLines = [];
      }
      currentTitle = heading.title;
      i = heading.nextIndex;
      continue;
    }
    currentLines.push(lines[i]);
  }
  flush();

  if (!chapters.length) return fallbackChunkSplit(text);
  if (chapters.length === 1 && countWords(chapters[0].text) > 7000) return fallbackChunkSplit(text);
  const explicitCount = chapters.filter((c) => /^(chapter|part|prologue|epilogue|interlude|preface|foreword|afterword)\b/i.test(c.title)).length;
  if (chapters.length <= 2 && explicitCount === 0 && /\bchapter\b/i.test(text) && countWords(text) > 5000) return fallbackChunkSplit(text);
  return chapters;
}

function detectChapterHeading(lines, index) {
  const current = (lines[index] || '').trim();
  const next = (lines[index + 1] || '').trim();
  const next2 = (lines[index + 2] || '').trim();
  const prev = (lines[index - 1] || '').trim();
  if (!current) return null;
  const numeral = '(?:\\d{1,3}|[ivxlcdm]+|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty)';
  const explicit = new RegExp(`^(chapter|chap\\.?|part)\\s+${numeral}(?:\\b|\\s|:|-).*$`, 'i');
  const specialSingle = /^(prologue|epilogue|interlude|preface|foreword|afterword)$/i;
  const specialTail = /^(prologue|epilogue|interlude|preface|foreword|afterword)\b.*$/i;
  const chapterOnly = /^(chapter|chap\.?|part)$/i;
  const numeralOnly = new RegExp(`^${numeral}$`, 'i');
  const chapterThenTitle = new RegExp(`^(chapter|chap\\.?|part)\\s+${numeral}[:\-]?\\s*$`, 'i');
  const centeredTitle = next && next.length < 70 && !/[.!?]$/.test(next);

  if (explicit.test(current)) {
    let title = current;
    let nextIndex = index;
    if (chapterThenTitle.test(current) && centeredTitle) {
      title = `${current} — ${next}`;
      nextIndex = index + 1;
    }
    return { title, nextIndex };
  }
  if (chapterOnly.test(current) && numeralOnly.test(next)) {
    const titleLine = next2 && next2.length < 70 && !/[.!?]$/.test(next2) ? ` — ${next2}` : '';
    return { title: `${current} ${next}${titleLine}`, nextIndex: titleLine ? index + 2 : index + 1 };
  }
  if (specialSingle.test(current) || specialTail.test(current)) {
    if (specialSingle.test(current) && centeredTitle && !specialTail.test(next)) return { title: `${current} — ${next}`, nextIndex: index + 1 };
    return { title: current, nextIndex: index };
  }
  const allCapsChapter = current.length < 72 && current === current.toUpperCase() && /\bCHAPTER\b/.test(current);
  if (allCapsChapter && !prev) return { title: current, nextIndex: index };
  return null;
}

function normalizeHeading(value) {
  return String(value || '').replace(/\s+/g, ' ').replace(/\s+[—-]\s+/g, ' — ').trim();
}

function fallbackChunkSplit(text) {
  const paragraphs = text.split(/\n\s*\n+/).map((p) => p.trim()).filter(Boolean);
  const targetParagraphs = Math.max(6, Math.ceil(paragraphs.length / 8));
  const chapters = [];
  for (let i = 0; i < paragraphs.length; i += targetParagraphs) {
    const slice = paragraphs.slice(i, i + targetParagraphs);
    chapters.push({ title: `Section ${chapters.length + 1}`, text: slice.join('\n\n'), paragraphs: slice });
  }
  return chapters;
}


function normalizeCharacterCandidate(value) {
  const cleaned = String(value || '')
    .replace(/[“”"'`]+/g, '')
    .replace(/(?:^|\s)([A-Za-z]+)'s\b/g, ' $1')
    .replace(/[:;,.!?]+$/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  if (!cleaned) return null;
  const rawTokens = cleaned.split(' ').filter(Boolean);
  const tokens = [...rawTokens];
  const first = tokens[0]?.replace(/\./g, '');
  if (CHARACTER_TITLES.has(first)) tokens.shift();
  if (!tokens.length || tokens.length > 3) return null;
  if (tokens.some((token) => !/^[A-Z][a-z]+$/.test(token))) return null;
  if (tokens.length === 1 && STOP_CAPITALIZED.has(tokens[0])) return null;
  return tokens.join(' ');
}

function candidateBelongsToProfile(name, profile) {
  if (!name || !profile) return false;
  if (name === profile.name || profile.aliases.has(name)) return true;
  const candidateTokens = name.split(' ');
  const profileTokens = profile.name.split(' ');
  const lastCandidate = candidateTokens[candidateTokens.length - 1];
  const lastProfile = profileTokens[profileTokens.length - 1];
  if (candidateTokens.length === 1) return profileTokens.includes(name) || [...profile.aliases].some((alias) => alias.split(' ').includes(name));
  if (profileTokens.length === 1) return candidateTokens.includes(profile.name);
  return lastCandidate === lastProfile || candidateTokens[0] === profileTokens[0];
}

function compileCharacterPattern(aliases) {
  const parts = [...new Set(aliases)].filter(Boolean).sort((a, b) => b.length - a.length).map((alias) => escapeRegex(alias));
  return parts.length ? new RegExp(`\\b(?:${parts.join('|')})\\b`) : /$a/;
}

function extractCharacterProfiles(text) {
  const rawCounts = new Map();
  const candidateRegex = /\b(?:Mr|Mrs|Ms|Miss|Mx|Dr|Professor|Prof|Captain|Capt|Sir|Lady|Lord|King|Queen|Prince|Princess)\.?\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)?|\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)?/g;
  const addCandidate = (candidate, weight = 1) => {
    const normalized = normalizeCharacterCandidate(candidate);
    if (!normalized) return;
    rawCounts.set(normalized, (rawCounts.get(normalized) || 0) + weight);
  };
  [...text.matchAll(candidateRegex)].forEach((match) => addCandidate(match[0], match[0].includes(' ') ? 1.2 : 1));
  const attributionPatterns = [
    new RegExp(`\\b([A-Z][a-z]+(?:\\s+[A-Z][a-z]+)?)\\s+(?:${DIALOGUE_ATTRIBUTION.join('|')})\\b`, 'g'),
    new RegExp(`(?:${DIALOGUE_ATTRIBUTION.join('|')})\\s+([A-Z][a-z]+(?:\\s+[A-Z][a-z]+)?)\\b`, 'g'),
  ];
  attributionPatterns.forEach((pattern) => { [...text.matchAll(pattern)].forEach((match) => addCandidate(match[1], 1.4)); });

  const profiles = [];
  [...rawCounts.entries()]
    .sort((a, b) => b[0].split(' ').length - a[0].split(' ').length || b[1] - a[1] || a[0].localeCompare(b[0]))
    .forEach(([name, count]) => {
      let profile = profiles.find((item) => candidateBelongsToProfile(name, item));
      if (!profile) {
        profile = { name, count: 0, aliases: new Set(), quotes: [], punctuation: { q: 0, ex: 0, ellipsis: 0 }, contractions: 0, shortQuotes: 0, longQuotes: 0, quoteCount: 0 };
        profiles.push(profile);
      }
      profile.count += count;
      profile.aliases.add(name);
      const tokens = name.split(' ');
      if (tokens[0]) profile.aliases.add(tokens[0]);
      if (tokens.length > 1) profile.aliases.add(tokens[tokens.length - 1]);
      const currentLength = profile.name.split(' ').length;
      if (tokens.length > currentLength || (tokens.length === currentLength && count > profile.count * 0.32)) profile.name = name;
    });

  return profiles
    .filter((profile) => profile.count >= 3 || (profile.count >= 2.4 && profile.name.includes(' ')))
    .sort((a, b) => b.count - a.count)
    .slice(0, 12)
    .map((profile) => {
      profile.aliases = [...profile.aliases].filter(Boolean);
      profile.pattern = compileCharacterPattern(profile.aliases);
      return profile;
    });
}

function buildCharacterMap(topCharacters) {
  const entries = new Map();
  topCharacters.forEach((profile) => {
    entries.set(profile.name, profile);
    profile.aliases.forEach((alias) => entries.set(alias, profile));
  });
  return entries;
}

function resolveCharacterCandidate(candidate, characterMap) {
  const normalized = normalizeCharacterCandidate(candidate);
  if (!normalized) return null;
  if (characterMap.has(normalized)) return characterMap.get(normalized).name;
  for (const profile of new Set(characterMap.values())) {
    if (candidateBelongsToProfile(normalized, profile)) return profile.name;
  }
  return null;
}

function extractQuoteSamples(text, characterMap) {
  const quoteRegex = /["“]([^"”]{2,})["”]/g;
  const samples = [];
  let match;
  while ((match = quoteRegex.exec(text))) {
    const rawText = match[0];
    const start = match.index;
    const end = start + rawText.length;
    samples.push({ text: rawText, content: match[1], start, end, speaker: inferQuoteSpeaker(text, start, end, characterMap) });
  }
  return samples;
}

function inferQuoteSpeaker(text, start, end, characterMap) {
  const before = text.slice(Math.max(0, start - 120), start);
  const after = text.slice(end, Math.min(text.length, end + 120));
  const beforePatterns = [
    new RegExp(`([A-Z][a-z]+(?:\\s+[A-Z][a-z]+)?)\\s*,?\\s*(?:${DIALOGUE_ATTRIBUTION.join('|')})\\s*$`),
  ];
  const afterPatterns = [
    new RegExp(`^\\s*[,—-]?\\s*(?:${DIALOGUE_ATTRIBUTION.join('|')})\\s+([A-Z][a-z]+(?:\\s+[A-Z][a-z]+)?)\\b`),
    new RegExp(`^\\s*[,—-]?\\s*([A-Z][a-z]+(?:\\s+[A-Z][a-z]+)?)\\s+(?:${DIALOGUE_ATTRIBUTION.join('|')})\\b`),
  ];
  for (const pattern of beforePatterns) {
    const match = before.match(pattern);
    const resolved = resolveCharacterCandidate(match?.[1], characterMap);
    if (resolved) return resolved;
  }
  for (const pattern of afterPatterns) {
    const match = after.match(pattern);
    const resolved = resolveCharacterCandidate(match?.[1], characterMap);
    if (resolved) return resolved;
  }
  return null;
}

function findPresentCharacters(text, topCharacters) {
  return topCharacters.filter((character) => character.pattern?.test(text));
}

function buildGlobalContext(chapterSeeds, config) {
  const fullText = chapterSeeds.map((c) => c.text).join('\n\n');
  const allParagraphs = chapterSeeds.flatMap((c) => c.paragraphs);
  const topCharacters = extractCharacterProfiles(fullText);
  const characterMap = buildCharacterMap(topCharacters);
  allParagraphs.forEach((paragraph) => collectQuoteProfiles(paragraph, characterMap));
  const motifCounts = new Map();
  tokenizeWords(fullText).forEach((word) => { if (ABSTRACT_WORDS.includes(word)) motifCounts.set(word, (motifCounts.get(word) || 0) + 1); });
  return {
    totalWords: countWords(fullText),
    motifs: [...motifCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8).map(([word]) => word),
    topCharacters,
    characterMap,
    genreSignalWords: GENRE_SIGNAL_WORDS[config.genre] || [],
    audience: AUDIENCE_THRESHOLDS[config.audience] || AUDIENCE_THRESHOLDS.adult,
    genreBias: GENRE_BIASES[config.genre] || GENRE_BIASES.general,
    draftWeights: DRAFT_WEIGHTS[config.draftStage] || DRAFT_WEIGHTS.middle,
    averageParagraphWords: average(allParagraphs.map((p) => countWords(p))),
    medianChapterWords: median(chapterSeeds.map((c) => countWords(c.text))),
    completion: config.completion / 100,
  };
}

function collectQuoteProfiles(paragraph, characterMap) {
  const quotes = extractQuoteSamples(paragraph, characterMap);
  if (!quotes.length) return;
  quotes.forEach((quote) => {
    if (!quote.speaker || !characterMap.has(quote.speaker)) return;
    const profile = characterMap.get(quote.speaker);
    const wordCount = countWords(quote.content);
    profile.quotes.push(wordCount);
    profile.quoteCount += 1;
    if (quote.text.includes('?')) profile.punctuation.q += 1;
    if (quote.text.includes('!')) profile.punctuation.ex += 1;
    if (quote.text.includes('...')) profile.punctuation.ellipsis += 1;
    if (/(?:[A-Za-z]+n't|[A-Za-z]+'(?:re|ve|ll|d|m|s))/.test(quote.content)) profile.contractions += 1;
    if (wordCount <= 6) profile.shortQuotes += 1;
    if (wordCount >= 20) profile.longQuotes += 1;
  });
}

function analyzeChapter(seed, chapterIndex, chapterCount, global) {
  const paragraphs = seed.paragraphs.map((text, paragraphIndex) => analyzeParagraph(text, chapterIndex, paragraphIndex, global));
  const issueMap = {};
  METRICS.forEach((metric) => {
    issueMap[metric.id] = paragraphs.map((paragraph) => paragraph.issues[metric.id]).filter(Boolean).sort((a, b) => b.severity - a.severity);
  });
  const features = mergeParagraphFeatures(paragraphs);
  const stagePosition = chapterCount === 1 ? global.completion : chapterIndex / Math.max(chapterCount - 1, 1);
  const earlyBookBoost = stagePosition <= 0.2 ? 1.08 : 1;
  const lateBookShield = stagePosition > global.completion + 0.05 ? 0.82 : 1;
  const metrics = {};

  metrics.clarity = clamp((96 - averageSeverity(issueMap.clarity) * 58 - features.filterRatio * 16 - features.longSentenceRatio * 14 - features.passiveRatio * 10) * global.audience.clarityBoost, 8, 98);
  metrics.pacing = clamp(92 - averageSeverity(issueMap.pacing) * 62 - features.staticSentenceShare * 14 - features.longParagraphRatio * 10 + features.sceneEnergy * 8, 8, 97);
  metrics.characters = clamp(88 - averageSeverity(issueMap.characters) * 52 + features.characterPresence * 18 + features.dialogueDensity * 6, 8, 96);
  metrics.creativity = clamp(87 - averageSeverity(issueMap.creativity) * 58 - features.clicheDensity * 18 - features.repetitionRatio * 16 + features.sensoryDensity * 5 + features.genreSignalDensity * 6, 8, 95);
  metrics.dialogue = clamp(88 - averageSeverity(issueMap.dialogue) * 58 + features.dialogueDensity * 16 + features.attributedDialogueDensity * 12 + features.characterPresence * 6, 8, 96);
  metrics.plot = clamp(90 - averageSeverity(issueMap.plot) * 60 + features.conflictDensity * 18 + features.causeDensity * 10 + features.questionDensity * 4 + features.genreSignalDensity * 4, 8, 97);
  metrics.setting = clamp(88 - averageSeverity(issueMap.setting) * 54 + features.sensoryDensity * 24 + features.settingDensity * 14 + features.genreSignalDensity * 10, 8, 96);
  metrics.grammar = clamp(94 - averageSeverity(issueMap.grammar) * 60 - features.grammarIssueRatio * 14 - features.adverbRatio * 6, 8, 98);
  metrics.opening = clamp((90 - averageSeverity(issueMap.opening) * 58 + features.openingPull * 18) * global.audience.openingBoost * earlyBookBoost, 8, 98);
  metrics.twists = clamp((84 - averageSeverity(issueMap.twists) * 52 + features.surpriseDensity * 16 + features.questionDensity * 8) * lateBookShield, 8, 95);
  metrics.themes = clamp((83 - averageSeverity(issueMap.themes) * 48 + features.themeDensity * 20 + global.motifs.length * 1.6) * lateBookShield, 8, 95);
  metrics.emotion = clamp((85 - averageSeverity(issueMap.emotion) * 50 + features.emotionDensity * 18 + features.conflictDensity * 6) * lateBookShield, 8, 96);
  metrics.inCharacter = clamp((87 - averageSeverity(issueMap.inCharacter) * 56 + features.dialogueDensity * 10 + features.attributedDialogueDensity * 14 + features.characterPresence * 8) * lateBookShield, 8, 96);

  metrics.twists = clamp(metrics.twists * 0.74 + metrics.plot * 0.26, 8, 96);
  metrics.pacing = clamp(metrics.pacing * 0.8 + metrics.plot * 0.12 + metrics.opening * 0.08, 8, 96);
  metrics.grammar = clamp(metrics.grammar * 0.82 + metrics.clarity * 0.12 + 5, 8, 98);
  metrics.inCharacter = clamp(metrics.inCharacter * 0.72 + metrics.characters * 0.2 + metrics.dialogue * 0.08, 8, 96);
  metrics.emotion = clamp(metrics.emotion * 0.8 + metrics.characters * 0.12 + metrics.plot * 0.08, 8, 96);
  metrics.themes = clamp(metrics.themes * 0.78 + metrics.plot * 0.12 + metrics.setting * 0.05 + global.completion * 8, 8, 95);

  Object.keys(metrics).forEach((id) => {
    const genreBias = global.genreBias[id] || 1;
    const draftBias = global.draftWeights[id] || 1;
    metrics[id] = clamp(metrics[id] * Math.pow(genreBias, 0.22) * Math.pow(draftBias, 0.16), 8, 98);
  });

  const confidence = buildConfidence(features, issueMap, countWords(seed.text), global);
  applyConfidenceGating(metrics, confidence);
  const supportiveSignals = buildSupportiveSignals(features, metrics, chapterIndex, global);
  const completeness = computeChapterCompleteness(metrics, global);
  return { index: chapterIndex, title: seed.title || `Chapter ${chapterIndex + 1}`, text: seed.text, paragraphs, issueMap, metrics: mapValues(metrics, (v) => Math.round(v)), confidence, supportiveSignals, completeness, wordCount: countWords(seed.text), features };
}

function mergeParagraphFeatures(paragraphs) {
  const list = paragraphs.map((p) => p.features);
  return {
    dialogueDensity: average(list.map((f) => f.dialogueRatio)), attributedDialogueDensity: average(list.map((f) => f.attributedDialogueRatio)), quoteAttributionRate: average(list.map((f) => f.quoteAttributionRate)), sceneEnergy: average(list.map((f) => f.actionRatio)), emotionDensity: average(list.map((f) => f.emotionRatio)), sensoryDensity: average(list.map((f) => f.sensoryRatio)), conflictDensity: average(list.map((f) => f.conflictRatio)), causeDensity: average(list.map((f) => f.causeRatio)), themeDensity: average(list.map((f) => f.themeRatio)), surpriseDensity: average(list.map((f) => f.surpriseRatio)), questionDensity: average(list.map((f) => f.questionRatio)), genreSignalDensity: average(list.map((f) => f.genreSignalRatio)), characterPresence: average(list.map((f) => f.characterPresence)), settingDensity: average(list.map((f) => f.settingRatio)), grammarIssueRatio: average(list.map((f) => f.grammarIssueRatio)), filterRatio: average(list.map((f) => f.filterRatio)), longSentenceRatio: average(list.map((f) => f.longSentenceRatio)), passiveRatio: average(list.map((f) => f.passiveRatio)), staticSentenceShare: average(list.map((f) => f.staticSentenceShare)), longParagraphRatio: average(list.map((f) => f.longParagraphRatio)), clicheDensity: average(list.map((f) => f.clicheRatio)), repetitionRatio: average(list.map((f) => f.repetitionRatio)), adverbRatio: average(list.map((f) => f.adverbRatio)), openingPull: average(list.slice(0, 2).map((f) => f.openingPull || 0)),
  };
}

function analyzeParagraph(text, chapterIndex, paragraphIndex, global) {
  const words = tokenizeWords(text);
  const lower = text.toLowerCase();
  const sentenceSpans = splitSentencesWithOffsets(text);
  const sentenceCount = Math.max(sentenceSpans.length, 1);
  const wordCount = words.length;
  const avgSentenceLength = wordCount / sentenceCount;
  const avgWordLength = words.length ? average(words.map((word) => word.length)) : 0;
  const quoteSamples = extractQuoteSamples(text, global.characterMap);
  const quoteMatches = quoteSamples.map((sample) => sample.text);
  const dialogueWords = sum(quoteSamples.map((sample) => countWords(sample.content)));
  const sensoryCount = countLexiconHits(words, SENSORY_WORDS);
  const emotionCount = countLexiconHits(words, EMOTION_WORDS);
  const abstractCount = countLexiconHits(words, ABSTRACT_WORDS.concat(global.motifs || []));
  const conflictCount = countLexiconHits(words, CONFLICT_WORDS);
  const actionCount = countLexiconHits(words, ACTION_WORDS);
  const settingCount = countLexiconHits(words, SETTING_WORDS);
  const questionCount = (text.match(/\?/g) || []).length;
  const exclamationCount = (text.match(/!/g) || []).length;
  const ellipsisCount = (text.match(/\.\.\./g) || []).length;
  const passiveCount = (text.match(/\b(?:was|were|is|are|been|be|being)\s+\w+(?:ed|en)\b/gi) || []).length;
  const fillerCount = countPhraseHits(lower, FILLER_PHRASES);
  const clicheCount = countPhraseHits(lower, CLICHE_PHRASES);
  const expositionCount = countPhraseHits(lower, EXPOSITION_PHRASES) + (text.match(/\b(?:had|used to|once|before|back when)\b/gi) || []).length;
  const surpriseCount = countPhraseHits(lower, SURPRISE_MARKERS);
  const adverbCount = (text.match(/\b\w+ly\b/gi) || []).length;
  const filterWordCount = countLexiconHits(words, FILTER_WORDS);
  const transitionCount = countPhraseHits(lower, SCENE_TRANSITION_MARKERS);
  const weakNarrationCount = countPhraseHits(lower, WEAK_NARRATION_PHRASES);
  const dialogueTagAdverbCount = (text.match(/\b(?:said|asked|replied|whispered|murmured)\s+\w+ly\b/gi) || []).length + (text.match(/\b\w+ly\s+(?:said|asked|replied|whispered|murmured)\b/gi) || []).length;
  const grammarIssueCount = (text.match(/\s{2,}/g) || []).length + (text.match(/\b(\w+)\s+\1\b/gi) || []).length + (text.match(/[!?]{2,}/g) || []).length + (text.match(/\s+[,.!?;:]/g) || []).length + (text.match(/(?:^|\s)i(?:\s|[.,!?;:])/g) || []).length;

  const namesPresent = findPresentCharacters(text, global.topCharacters);
  const characterPresence = global.topCharacters.length ? namesPresent.length / Math.min(global.topCharacters.length, 4) : 0;
  const attributedQuoteCount = quoteSamples.filter((sample) => sample.speaker).length;
  const attributedDialogueWords = sum(quoteSamples.filter((sample) => sample.speaker).map((sample) => countWords(sample.content)));
  const dialogueRatio = safeRatio(dialogueWords, wordCount);
  const attributedDialogueRatio = safeRatio(attributedDialogueWords, wordCount);
  const actionRatio = safeRatio(actionCount, Math.max(wordCount / 16, 1));
  const emotionRatio = safeRatio(emotionCount, Math.max(wordCount / 18, 1));
  const sensoryRatio = safeRatio(sensoryCount + settingCount, Math.max(wordCount / 18, 1));
  const conflictRatio = safeRatio(conflictCount, Math.max(wordCount / 18, 1));
  const causeRatio = safeRatio((text.match(/\b(?:because|therefore|so that|which meant|as a result|thereby|forcing|led to|causing)\b/gi) || []).length, sentenceCount);
  const expositionRatio = safeRatio(expositionCount + fillerCount + weakNarrationCount, sentenceCount);
  const themeRatio = safeRatio(abstractCount, Math.max(wordCount / 20, 1));
  const surpriseRatio = safeRatio(surpriseCount + questionCount + transitionCount, sentenceCount);
  const questionRatio = safeRatio(questionCount, sentenceCount);
  const longSentenceRatio = safeRatio(sentenceSpans.filter((s) => countWords(s.text) > global.audience.targetSentence + 10).length, sentenceCount);
  const staticSentenceShare = safeRatio(sentenceSpans.filter((s) => sentenceStaticScore(s.text) > 0.64).length, sentenceCount);
  const genreSignalCount = countLexiconHits(words, global.genreSignalWords || []);
  const settingRatio = safeRatio(settingCount, Math.max(wordCount / 28, 1));
  const genreSignalRatio = safeRatio(genreSignalCount, Math.max(wordCount / 22, 1));
  const clicheRatio = safeRatio(clicheCount, 2);
  const repetitionRatio = repeatedWordRate(text);
  const grammarIssueRatio = safeRatio(grammarIssueCount, 4);
  const filterRatio = safeRatio(filterWordCount, Math.max(sentenceCount * 2, 1));
  const passiveRatio = safeRatio(passiveCount, sentenceCount);
  const longParagraphRatio = wordCount > Math.max(global.averageParagraphWords * 1.45, 140) ? clamp((wordCount - global.averageParagraphWords) / 240, 0, 1) : 0;
  const adverbRatio = safeRatio(adverbCount + dialogueTagAdverbCount, Math.max(sentenceCount * 2, 1));
  const quoteAttributionRate = safeRatio(attributedQuoteCount, Math.max(quoteSamples.length, 1));
  const openingPull = clamp(conflictRatio * 0.46 + questionRatio * 0.28 + actionRatio * 0.16 + genreSignalRatio * 0.08 - expositionRatio * 0.2, 0, 1);

  const paragraphId = `c${chapterIndex + 1}-p${paragraphIndex + 1}`;
  const issues = {};
  const audience = global.audience;
  const sentencePenalty = Math.max(0, (avgSentenceLength - audience.targetSentence) / (audience.targetSentence + 6));
  const wordPenalty = Math.max(0, (avgWordLength - audience.targetWord) / 2.3);

  maybeAddIssue(issues, 'clarity', paragraphId, chapterIndex, paragraphIndex, clamp(sentencePenalty * 0.34 + wordPenalty * 0.14 + passiveRatio * 0.18 + expositionRatio * 0.14 + filterRatio * 0.1 + longSentenceRatio * 0.1, 0, 1), 0.23, summarizeReasons([sentencePenalty > 0.18 ? 'Very long sentence flow' : '', wordPenalty > 0.16 ? 'Dense wording' : '', passiveRatio > 0.22 ? 'Passive constructions' : '', filterRatio > 0.22 ? 'Filter / telling language' : '', expositionRatio > 0.5 ? 'High explanatory load' : '']), text);
  maybeAddIssue(issues, 'pacing', paragraphId, chapterIndex, paragraphIndex, clamp(longParagraphRatio * 0.34 + expositionRatio * 0.24 + staticSentenceShare * 0.18 + (1 - actionRatio) * 0.12 + (1 - dialogueRatio) * 0.04 + safeRatio(transitionCount, sentenceCount) * 0.08, 0, 1), wordCount > 65 ? 0.25 : 1.1, summarizeReasons([longParagraphRatio > 0.2 ? 'Paragraph may be dragging' : '', expositionRatio > 0.42 ? 'Exposition outweighs movement' : '', staticSentenceShare > 0.3 ? 'Several sentences stay static' : '', actionRatio < 0.12 ? 'Low scene energy' : '']), text);
  maybeAddIssue(issues, 'characters', paragraphId, chapterIndex, paragraphIndex, clamp((1 - characterPresence) * 0.36 + (1 - dialogueRatio) * 0.08 + (1 - actionRatio) * 0.08 + (wordCount > 120 && namesPresent.length === 0 ? 0.24 : 0) + (dialogueRatio > 0.3 && namesPresent.length === 0 ? 0.1 : 0), 0, 1), wordCount > 55 ? 0.32 : 1.1, summarizeReasons([namesPresent.length === 0 ? 'Low character presence' : '', dialogueRatio < 0.08 ? 'Little character voice on page' : '', actionRatio < 0.14 ? 'Low visible agency' : '']), text);
  maybeAddIssue(issues, 'creativity', paragraphId, chapterIndex, paragraphIndex, clamp(clicheRatio * 0.6 + safeRatio(fillerCount, 3) * 0.12 + repetitionRatio * 0.18 + safeRatio(weakNarrationCount, 2) * 0.1 - genreSignalRatio * 0.08, 0, 1), 0.2, summarizeReasons([clicheCount ? 'Contains familiar stock phrasing' : '', fillerCount > 1 ? 'Relies on generic connective language' : '', repetitionRatio > 0.07 ? 'Repetitive wording' : '', weakNarrationCount > 0 ? 'Generic narrative scaffolding' : '']), text);

  const overlongQuotePenalty = quoteMatches.some((quote) => countWords(quote) > 45) ? 0.32 : 0;
  const expositoryDialoguePenalty = quoteMatches.some((quote) => /as you know|remember when|let me explain|for years/i.test(quote)) ? 0.34 : 0;
  maybeAddIssue(issues, 'dialogue', paragraphId, chapterIndex, paragraphIndex, clamp((quoteMatches.length ? 0 : 0.08) + overlongQuotePenalty + expositoryDialoguePenalty + (dialogueTagAdverbCount ? 0.14 : 0) + (exclamationCount > 2 ? 0.12 : 0) + (ellipsisCount > 2 ? 0.1 : 0), 0, 1), quoteMatches.length ? 0.23 : 1.1, summarizeReasons([overlongQuotePenalty ? 'Speech block is unusually long' : '', expositoryDialoguePenalty ? 'Dialogue sounds explanatory' : '', dialogueTagAdverbCount ? 'Dialogue tags may be over-directed' : '', exclamationCount > 2 ? 'Heavy punctuation inside dialogue' : '', ellipsisCount > 2 ? 'Frequent trailing pauses' : '']), text);
  maybeAddIssue(issues, 'plot', paragraphId, chapterIndex, paragraphIndex, clamp((1 - conflictRatio) * 0.24 + (1 - causeRatio) * 0.18 + expositionRatio * 0.2 + staticSentenceShare * 0.12 + (1 - questionRatio) * 0.06 + (wordCount > 95 && actionRatio < 0.12 ? 0.14 : 0), 0, 1), wordCount > 68 ? 0.3 : 1.1, summarizeReasons([conflictRatio < 0.16 ? 'Low visible conflict or stakes' : '', causeRatio < 0.2 ? 'Weak cause-and-effect language' : '', expositionRatio > 0.42 ? 'Backstory / explanation dominates' : '', staticSentenceShare > 0.3 ? 'Scene progression may be thin' : '']), text);
  maybeAddIssue(issues, 'setting', paragraphId, chapterIndex, paragraphIndex, clamp((wordCount > 85 ? (1 - sensoryRatio) * 0.36 : 0) + (1 - settingRatio) * 0.18 + (dialogueRatio > 0.45 ? 0.1 : 0) + filterRatio * 0.08 - genreSignalRatio * 0.1, 0, 1), wordCount > 82 ? 0.28 : 1.1, summarizeReasons([sensoryRatio < 0.18 ? 'Low sensory grounding' : '', settingCount === 0 && genreSignalCount === 0 ? 'Sparse environmental detail' : '', dialogueRatio > 0.45 ? 'Conversation may be floating without place cues' : '']), text);
  maybeAddIssue(issues, 'grammar', paragraphId, chapterIndex, paragraphIndex, clamp(grammarIssueRatio * 0.5 + adverbRatio * 0.12 + sentencePenalty * 0.14 + safeRatio(dialogueTagAdverbCount, 2) * 0.08 + (text.includes('??') || text.includes('!!') ? 0.1 : 0), 0, 1), 0.16, summarizeReasons([grammarIssueCount > 0 ? 'Mechanical cleanup signal' : '', adverbCount > sentenceCount ? 'Adverb density is high' : '', dialogueTagAdverbCount ? 'Dialogue tag construction may read purple' : '', sentencePenalty > 0.2 ? 'Sentence control may need tightening' : '']), text);
  const isOpeningWindow = paragraphIndex <= 1;
  maybeAddIssue(issues, 'opening', paragraphId, chapterIndex, paragraphIndex, isOpeningWindow ? clamp((1 - conflictRatio) * 0.24 + (1 - questionRatio) * 0.16 + (1 - actionRatio) * 0.12 + expositionRatio * 0.2 + staticSentenceShare * 0.1 + (wordCount > 150 ? 0.08 : 0), 0, 1) : 0, isOpeningWindow ? 0.23 : 1.1, summarizeReasons([conflictRatio < 0.14 ? 'Low opening tension' : '', questionRatio < 0.12 ? 'Limited curiosity pull' : '', expositionRatio > 0.38 ? 'Opens with explanation instead of movement' : '', staticSentenceShare > 0.3 ? 'Opening motion feels muted' : '']), text);
  maybeAddIssue(issues, 'twists', paragraphId, chapterIndex, paragraphIndex, clamp(clicheRatio * 0.3 + (1 - surpriseRatio) * 0.3 + (1 - conflictRatio) * 0.06 + staticSentenceShare * 0.08 + (paragraphIndex > 1 ? 0.08 : 0), 0, 1), wordCount > 58 ? 0.28 : 1.1, summarizeReasons([surpriseRatio < 0.16 ? 'Low surprise or reversal language' : '', clicheCount ? 'Predictability cues from familiar phrasing' : '', staticSentenceShare > 0.35 ? 'Beat may resolve exactly as expected' : '']), text);
  maybeAddIssue(issues, 'themes', paragraphId, chapterIndex, paragraphIndex, clamp((wordCount > 95 ? (1 - themeRatio) * 0.36 : 0.05) + (expositionRatio > 0.58 ? 0.12 : 0) + safeRatio(weakNarrationCount, 2) * 0.08, 0, 1), wordCount > 90 ? 0.28 : 1.1, summarizeReasons([themeRatio < 0.14 ? 'Low recurring idea or motif language' : '', expositionRatio > 0.58 ? 'Abstract meaning may not be dramatized yet' : '']), text);
  maybeAddIssue(issues, 'emotion', paragraphId, chapterIndex, paragraphIndex, clamp((wordCount > 75 ? (1 - emotionRatio) * 0.28 : 0.05) + (1 - conflictRatio) * 0.12 + (dialogueRatio < 0.05 && namesPresent.length === 0 ? 0.1 : 0) + filterRatio * 0.08, 0, 1), wordCount > 72 ? 0.28 : 1.1, summarizeReasons([emotionRatio < 0.18 ? 'Low emotional language' : '', conflictRatio < 0.12 ? 'Pressure may not be landing on the page' : '', namesPresent.length === 0 ? 'Limited character anchoring for emotion' : '']), text);
  const inCharacterSignal = evaluateVoiceConsistency(text, quoteSamples, global);
  maybeAddIssue(issues, 'inCharacter', paragraphId, chapterIndex, paragraphIndex, clamp((1 - inCharacterSignal) * 0.68 + (quoteMatches.length ? 0 : 0.04) + (dialogueTagAdverbCount ? 0.06 : 0), 0, 1), quoteMatches.length ? 0.26 : 1.1, summarizeReasons([inCharacterSignal < 0.45 ? 'Character voice deviates from observed pattern' : '', quoteMatches.length > 1 && exclamationCount > 1 ? 'Speech style may be over-amplified' : '', dialogueTagAdverbCount ? 'Delivery beats may be over-signaled' : '']), text);

  return { id: paragraphId, text, paragraphIndex, features: { wordCount, sentenceCount, dialogueRatio, attributedDialogueRatio, quoteAttributionRate, actionRatio, emotionRatio, sensoryRatio, conflictRatio, causeRatio, expositionRatio, themeRatio, surpriseRatio, questionRatio, genreSignalRatio, characterPresence, settingRatio, grammarIssueRatio, filterRatio, longSentenceRatio, passiveRatio, staticSentenceShare, longParagraphRatio, clicheRatio, repetitionRatio, adverbRatio, openingPull }, issues };
}

function maybeAddIssue(issues, metricId, paragraphId, chapterIndex, paragraphIndex, severity, threshold, reason, text) {
  if (severity <= threshold) return;
  issues[metricId] = { metricId, paragraphId, chapterIndex, paragraphIndex, severity: clamp(Number(severity.toFixed(3)), 0, 1), reason: reason || 'Potential revision hotspot', excerpt: text.trim(), fragments: inferIssueFragments(metricId, text.trim(), reason || '') };
}

function inferIssueFragments(metricId, text, reason = '') {
  const fragments = [];
  const push = (items) => items.forEach((item) => fragments.push(item));
  switch (metricId) {
    case 'clarity':
      push(findPhraseRanges(text, FILLER_PHRASES, 'Filler / indirect phrasing'));
      push(findRegexRanges(text, /\b(?:was|were|is|are|been|be|being)\s+\w+(?:ed|en)\b/gi, 'Passive construction'));
      push(findRegexRanges(text, /\b(?:saw|felt|noticed|realized|thought|wondered|heard|seemed)\b/gi, 'Filter / telling word'));
      break;
    case 'pacing':
      push(findPhraseRanges(text, EXPOSITION_PHRASES.concat(WEAK_NARRATION_PHRASES), 'Expository setup'));
      break;
    case 'characters':
      push(findQuoteRanges(text, 'Dialogue / character voice'));
      push(findCapitalizedNameRanges(text, 'Character reference'));
      break;
    case 'creativity':
      push(findPhraseRanges(text, CLICHE_PHRASES, 'Cliché / familiar phrasing'));
      push(findRepeatedWordRanges(text, 'Repeated wording'));
      break;
    case 'dialogue':
      push(findQuoteRanges(text, 'Dialogue block'));
      push(findRegexRanges(text, /\b(?:said|asked|replied|whispered|murmured)\s+\w+ly\b/gi, 'Over-directed dialogue tag'));
      push(findRegexRanges(text, /\b\w+ly\s+(?:said|asked|replied|whispered|murmured)\b/gi, 'Over-directed dialogue tag'));
      break;
    case 'plot':
      push(findPhraseRanges(text, EXPOSITION_PHRASES, 'Backstory / explanation'));
      push(findPhraseRanges(text, SURPRISE_MARKERS, 'Turn / reversal language'));
      break;
    case 'setting':
      push(findLexiconRanges(text, SENSORY_WORDS.concat(SETTING_WORDS), 'Setting / sensory cue'));
      push(findQuoteRanges(text, 'Dialogue floating without setting'));
      break;
    case 'grammar':
      push(findRegexRanges(text, /\b(\w+)\s+\1\b/gi, 'Repeated word'));
      push(findRegexRanges(text, /[!?]{2,}/g, 'Punctuation pileup'));
      push(findRegexRanges(text, /\b\w+ly\b/gi, 'Adverb-heavy construction'));
      break;
    case 'opening':
      push(findPhraseRanges(text, EXPOSITION_PHRASES.concat(WEAK_NARRATION_PHRASES), 'Opening exposition'));
      break;
    case 'twists':
      push(findPhraseRanges(text, CLICHE_PHRASES, 'Predictable phrasing'));
      push(findPhraseRanges(text, SURPRISE_MARKERS, 'Reversal marker'));
      break;
    case 'themes':
      push(findLexiconRanges(text, ABSTRACT_WORDS, 'Abstract / thematic language'));
      push(findPhraseRanges(text, EXPOSITION_PHRASES, 'Explained instead of dramatized'));
      break;
    case 'emotion':
      push(findLexiconRanges(text, EMOTION_WORDS, 'Emotional cue'));
      push(findQuoteRanges(text, 'Emotional dialogue beat'));
      break;
    case 'inCharacter':
      push(findQuoteRanges(text, 'Character voice sample'));
      break;
    default:
      break;
  }
  if (!fragments.length) push(selectFallbackSentenceRanges(metricId, splitSentencesWithOffsets(text), reason));
  return normalizeFragments(fragments, text);
}

function selectFallbackSentenceRanges(metricId, sentences, reason) {
  if (!sentences.length) return [];
  const ranked = sentences.map((sentence) => ({ ...sentence, score: sentenceMetricScore(metricId, sentence.text) })).sort((a, b) => b.score - a.score || b.text.length - a.text.length);
  const best = ranked[0] || sentences[0];
  return best ? [{ start: best.start, end: best.end, label: reason || 'Flagged sentence' }] : [];
}

function sentenceMetricScore(metricId, text) {
  const lower = text.toLowerCase();
  const words = tokenizeWords(text);
  const lengthScore = countWords(text) / 28;
  switch (metricId) {
    case 'clarity': return lengthScore + countPhraseHits(lower, FILLER_PHRASES) * 0.8 + countLexiconHits(words, FILTER_WORDS) * 0.45 + (/\b(?:was|were|is|are|been|be|being)\s+\w+(?:ed|en)\b/i.test(text) ? 1.2 : 0);
    case 'pacing': return countPhraseHits(lower, EXPOSITION_PHRASES.concat(WEAK_NARRATION_PHRASES)) * 0.9 + sentenceStaticScore(text) * 2 + lengthScore * 0.4;
    case 'characters': return (countCapitalizedNames(text) ? 0.9 : 0.2) + ((text.match(/["“][^"”]{2,}["”]/g) || []).length * 0.6);
    case 'creativity': return countPhraseHits(lower, CLICHE_PHRASES) * 1.5 + repeatedWordRate(text) * 4;
    case 'dialogue': return ((text.match(/["“][^"”]{2,}["”]/g) || []).length * 1.2) + ((text.match(/\b\w+ly\s+(?:said|asked|replied)|(?:said|asked|replied)\s+\w+ly\b/gi) || []).length * 1.3);
    case 'plot': return countPhraseHits(lower, EXPOSITION_PHRASES) + sentenceStaticScore(text) * 1.8;
    case 'setting': return ((text.match(/["“][^"”]{2,}["”]/g) || []).length ? 1.3 : 0.3) + (countLexiconHits(words, SENSORY_WORDS.concat(SETTING_WORDS)) ? 0.2 : 0.9);
    case 'grammar': return ((text.match(/\b(\w+)\s+\1\b/gi) || []).length * 1.5) + ((text.match(/[!?]{2,}/g) || []).length * 1.2) + ((text.match(/\b\w+ly\b/gi) || []).length * 0.2) + lengthScore * 0.3;
    case 'opening': return countPhraseHits(lower, EXPOSITION_PHRASES.concat(WEAK_NARRATION_PHRASES)) * 1.2 + sentenceStaticScore(text) * 1.6;
    case 'twists': return countPhraseHits(lower, CLICHE_PHRASES) * 1.2 + sentenceStaticScore(text) * 1.1;
    case 'themes': return countPhraseHits(lower, EXPOSITION_PHRASES) * 0.8 + countLexiconHits(words, ABSTRACT_WORDS) * 0.5 + sentenceStaticScore(text) * 0.9;
    case 'emotion': return (countLexiconHits(words, EMOTION_WORDS) ? 0.4 : 0) + sentenceStaticScore(text) * 1.5 + (countCapitalizedNames(text) ? 0.2 : 0.8);
    case 'inCharacter': return ((text.match(/["“][^"”]{2,}["”]/g) || []).length * 1.5) + ((text.match(/\b\w+ly\s+(?:said|asked|replied)|(?:said|asked|replied)\s+\w+ly\b/gi) || []).length * 0.6);
    default: return lengthScore;
  }
}

function sentenceStaticScore(text) {
  const words = tokenizeWords(text);
  const action = countLexiconHits(words, ACTION_WORDS.concat(CONFLICT_WORDS));
  const telling = countLexiconHits(words, TELLING_WORDS.concat(FILTER_WORDS));
  const exposition = countPhraseHits(text.toLowerCase(), EXPOSITION_PHRASES.concat(WEAK_NARRATION_PHRASES));
  return clamp((telling * 0.18) + (exposition * 0.32) + Math.max(0, 1 - safeRatio(action, Math.max(words.length / 14, 1))) * 0.7, 0, 1.4);
}

function buildConfidence(features, issueMap, chapterWordCount, global) {
  const quoteEvidence = sum(['dialogue', 'inCharacter'].map((id) => issueMap[id].length));
  const conceptEvidence = issueMap.themes.length + issueMap.emotion.length;
  const characterEvidence = global.topCharacters.length;
  return {
    clarity: Math.round(clamp(62 + chapterWordCount / 240 + features.longSentenceRatio * 10, 48, 98)),
    pacing: Math.round(clamp(44 + chapterWordCount / 260 + features.sceneEnergy * 18 + features.dialogueDensity * 10, 30, 94)),
    characters: Math.round(clamp(34 + characterEvidence * 5 + features.characterPresence * 22 + features.attributedDialogueDensity * 18, 20, 94)),
    creativity: Math.round(clamp(34 + chapterWordCount / 260 + features.genreSignalDensity * 16 - features.clicheDensity * 18, 24, 88)),
    dialogue: Math.round(clamp(40 + features.dialogueDensity * 44 + features.attributedDialogueDensity * 32 + quoteEvidence * 2, 24, 96)),
    plot: Math.round(clamp(38 + chapterWordCount / 260 + features.conflictDensity * 24 + features.causeDensity * 18, 26, 94)),
    setting: Math.round(clamp(36 + chapterWordCount / 280 + features.settingDensity * 28 + features.sensoryDensity * 18 + features.genreSignalDensity * 14, 24, 94)),
    grammar: Math.round(clamp(68 + chapterWordCount / 260 - features.grammarIssueRatio * 10, 54, 98)),
    opening: Math.round(clamp(34 + chapterWordCount / 320 + features.openingPull * 36, 22, 92)),
    twists: Math.round(clamp(26 + features.surpriseDensity * 42 + features.questionDensity * 14 + features.genreSignalDensity * 6, 18, 84)),
    themes: Math.round(clamp(24 + features.themeDensity * 56 + conceptEvidence * 1.5, 15, 80)),
    emotion: Math.round(clamp(28 + features.emotionDensity * 54 + features.conflictDensity * 10, 18, 86)),
    inCharacter: Math.round(clamp(18 + quoteEvidence * 2.4 + features.attributedDialogueDensity * 48 + features.quoteAttributionRate * 18 + characterEvidence * 3, 14, 84)),
  };
}

function applyConfidenceGating(metrics, confidence) {
  METRICS.forEach((metric) => {
    const confidenceValue = confidence[metric.id];
    if (!Number.isFinite(confidenceValue)) return;
    const gate = clamp(confidenceValue / 100, 0.18, 1);
    const neutral = metric.subjective ? 50 : 60;
    metrics[metric.id] = clamp(neutral + ((metrics[metric.id] - neutral) * (0.42 + gate * 0.58)), 8, 98);
  });
}

function buildSupportiveSignals(features, metrics, chapterIndex, global) {
  const signals = {};
  const add = (metricId, ...items) => { signals[metricId] = items.filter(Boolean).slice(0, 3); };
  add('clarity', metrics.clarity >= 70 && features.longSentenceRatio < 0.2 ? 'Sentence flow is mostly readable' : '', features.filterRatio < 0.16 ? 'Limited filter-language clutter' : '');
  add('pacing', metrics.pacing >= 70 && features.sceneEnergy >= 0.18 ? 'Scenes show forward movement' : '', features.dialogueDensity >= 0.12 ? 'Dialogue helps scenes move' : '');
  add('characters', metrics.characters >= 68 && features.characterPresence >= 0.2 ? 'Named characters appear consistently' : '', features.attributedDialogueDensity >= 0.08 ? 'Voices are tied to on-page characters' : '');
  add('creativity', metrics.creativity >= 68 && features.clicheDensity < 0.08 ? 'Low cliché density in this section' : '', features.genreSignalDensity >= 0.16 ? 'Genre-specific texture comes through on the page' : '');
  add('dialogue', metrics.dialogue >= 68 && features.dialogueDensity >= 0.12 ? 'Dialogue is present often enough to judge' : '', features.quoteAttributionRate >= 0.45 ? 'Many speech beats have identifiable speakers' : '');
  add('plot', metrics.plot >= 68 && features.conflictDensity >= 0.14 ? 'Conflict shows up on the page' : '', features.causeDensity >= 0.14 ? 'Cause-and-effect language is visible' : '');
  add('setting', metrics.setting >= 68 && features.sensoryDensity >= 0.16 ? 'Scenes include sensory grounding' : '', features.genreSignalDensity >= 0.14 ? 'World texture matches the selected genre' : '');
  add('grammar', metrics.grammar >= 72 && features.grammarIssueRatio < 0.14 ? 'Mechanical noise stays fairly low' : '', features.adverbRatio < 0.16 ? 'Modifiers are not overwhelming the prose' : '');
  add('opening', chapterIndex === 0 && metrics.opening >= 68 && features.openingPull >= 0.22 ? 'Opening paragraphs show some pull' : '');
  add('twists', metrics.twists >= 64 && features.surpriseDensity >= 0.12 ? 'There are visible reversal or surprise cues' : '');
  add('themes', metrics.themes >= 64 && features.themeDensity >= 0.12 ? 'Motif language recurs often enough to register' : '', global.motifs.length >= 3 ? 'The manuscript repeats a few larger-idea words' : '');
  add('emotion', metrics.emotion >= 64 && features.emotionDensity >= 0.12 ? 'Emotional language is present on the page' : '', features.conflictDensity >= 0.14 ? 'Pressure supports the emotional beats' : '');
  add('inCharacter', metrics.inCharacter >= 64 && features.quoteAttributionRate >= 0.45 ? 'Enough attributed dialogue exists to compare voices' : '', features.attributedDialogueDensity >= 0.08 ? 'Speaker patterns are trackable across quotes' : '');
  return signals;
}

function computeChapterCompleteness(metrics, global) {
  const weights = global.draftWeights;
  const prose = weightedAverage([[metrics.clarity, weights.clarity || 1], [metrics.grammar, (weights.grammar || 1) * 0.85]]);
  const structure = weightedAverage([[metrics.plot, weights.plot || 1], [metrics.pacing, weights.pacing || 1], [metrics.opening, weights.opening || 1]]);
  const immersion = weightedAverage([[metrics.setting, weights.setting || 1]]);
  return Math.round(weightedAverage([[prose, 1.15], [structure, 1.35], [immersion, 0.7]]));
}

function aggregateOverall(chapters, global, config) {
  const metrics = {};
  METRICS.forEach((metric) => { metrics[metric.id] = Math.round(weightedAverage(chapters.map((chapter) => [chapter.metrics[metric.id], Math.max(chapter.wordCount, 80)]))); });
  const confidence = {};
  METRICS.forEach((metric) => { confidence[metric.id] = Math.round(weightedAverage(chapters.map((chapter) => [chapter.confidence[metric.id] || 0, Math.max(chapter.wordCount, 80)]))); });
  const completeness = Math.round(weightedAverage(chapters.map((chapter) => [chapter.completeness, Math.max(chapter.wordCount, 80)])));
  const subjectiveMean = Math.round(average(SUBJECTIVE_IDS.map((id) => metrics[id])));
  const averageConfidence = Math.round(average(SUBJECTIVE_IDS.map((id) => confidence[id] || 0)));
  const worstChapter = chapters.slice().sort((a, b) => a.completeness - b.completeness)[0];
  const allHighlights = {};
  const supportiveSignals = {};
  METRICS.forEach((metric) => {
    allHighlights[metric.id] = chapters.flatMap((chapter) => chapter.issueMap[metric.id].map((issue) => ({ ...issue, chapterTitle: chapter.title }))).sort((a, b) => b.severity - a.severity);
    const counts = new Map();
    chapters.forEach((chapter) => {
      (chapter.supportiveSignals?.[metric.id] || []).forEach((signal) => counts.set(signal, (counts.get(signal) || 0) + 1));
    });
    supportiveSignals[metric.id] = [...counts.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])).slice(0, 3).map(([signal]) => signal);
  });
  return { metrics, confidence, completeness, subjectiveMean, averageConfidence, allHighlights, supportiveSignals, worstChapter, chapterCount: chapters.length, totalWords: global.totalWords, draftStage: config.draftStage, completion: config.completion };
}

function renderAll() { renderSummary(); renderOverallBars(); renderHeatmap(); renderTrendChart(); renderFindings(); renderManuscript(); }

function renderSummary() {
  const analysis = state.analysis;
  if (!analysis) {
    els.summaryCards.className = 'summary-cards empty-state';
    els.summaryCards.innerHTML = '<div class="empty-copy">Upload a manuscript to generate overall revision pressure, chapter counts, confidence markers, and dashboard cards.</div>';
    return;
  }
  const overall = analysis.overall;
  els.summaryCards.className = 'summary-cards';
  els.summaryCards.innerHTML = [
    cardHtml('Overall completeness', `${overall.completeness}%`, 'Objective revision pressure only. Subjective metrics excluded.'),
    cardHtml('Average subjective score', `${overall.subjectiveMean}%`, `Confidence avg: ${overall.averageConfidence}%`),
    cardHtml('Chapters detected', `${overall.chapterCount}`, `${formatNumber(overall.totalWords)} words indexed locally`),
    cardHtml('Highest revision pressure', `${overall.worstChapter?.index + 1 || '—'}`, overall.worstChapter ? `${escapeHtml(overall.worstChapter.title)} · ${overall.worstChapter.completeness}%` : '—'),
  ].join('');
}

function cardHtml(kicker, strong, small) {
  return `<article class="summary-card"><span class="kicker">${escapeHtml(kicker)}</span><strong>${escapeHtml(String(strong))}</strong><small>${escapeHtml(String(small))}</small></article>`;
}

function renderOverallBars() {
  const analysis = state.analysis;
  if (!analysis) { els.overallBars.innerHTML = ''; return; }
  els.overallBars.innerHTML = METRICS.map((metric) => {
    const score = analysis.overall.metrics[metric.id];
    const confidence = analysis.overall.confidence[metric.id];
    const selected = state.selectedMetricId === metric.id;
    return `
      <div class="metric-bar ${selected ? 'active' : ''}">
        <div class="fill" style="width:${score}%; background:${barGradient(score, metric.subjective)}"></div>
        <button type="button" data-metric-button="${metric.id}">
          <div class="meta">
            <strong>${escapeHtml(metric.title)}</strong>
            <div class="mini">
              <span>${escapeHtml(metric.lowLabel)} → ${escapeHtml(metric.highLabel)}</span>
              ${metric.subjective ? `<span class="metric-chip subjective">Subjective · confidence ${confidence}%</span>` : `<span class="metric-chip">Included in completeness</span>`}
            </div>
          </div>
          <div class="score">${score}%</div>
        </button>
      </div>
    `;
  }).join('');
  els.overallBars.querySelectorAll('[data-metric-button]').forEach((button) => {
    button.addEventListener('click', () => {
      state.selectedMetricId = button.dataset.metricButton;
      state.selectedChapterIndex = null;
      els.trendMetricSelect.value = state.selectedMetricId;
      renderAll();
    });
  });
}

function renderHeatmap() {
  const analysis = state.analysis;
  if (!analysis) {
    els.heatmapWrap.className = 'heatmap-wrap empty-state';
    els.heatmapWrap.innerHTML = '<div class="empty-copy">Heatmap scores will appear here after analysis.</div>';
    return;
  }
  const header = ['<th>Chapter</th>'].concat(METRICS.map((metric) => `<th title="${escapeHtml(metric.description)}">${escapeHtml(shortMetricTitle(metric.title))}</th>`)).join('');
  const rows = analysis.chapters.map((chapter) => {
    const cells = METRICS.map((metric) => {
      const score = chapter.metrics[metric.id];
      const active = state.selectedMetricId === metric.id && state.selectedChapterIndex === chapter.index;
      return `
        <td>
          <button class="heatmap-cell ${active ? 'active' : ''}" type="button" data-heatmap-cell="${metric.id}::${chapter.index}" style="background:${heatmapColor(score, metric.subjective)};${metric.subjective ? 'box-shadow: inset 0 0 0 1px rgba(96,116,155,.35);' : ''}" title="${escapeHtml(metric.title)} · ${score}%">${score}</button>
        </td>
      `;
    }).join('');
    return `<tr><th>${chapter.index + 1}. ${escapeHtml(chapter.title)}</th>${cells}</tr>`;
  }).join('');
  els.heatmapWrap.className = 'heatmap-wrap';
  els.heatmapWrap.innerHTML = `<table class="heatmap-table"><thead><tr>${header}</tr></thead><tbody>${rows}</tbody></table>`;
  els.heatmapWrap.querySelectorAll('[data-heatmap-cell]').forEach((button) => {
    button.addEventListener('click', () => {
      const [metricId, chapterIndex] = button.dataset.heatmapCell.split('::');
      state.selectedMetricId = metricId;
      state.selectedChapterIndex = Number(chapterIndex);
      els.trendMetricSelect.value = metricId;
      renderAll();
    });
  });
}

function renderTrendChart() {
  const analysis = state.analysis;
  if (!analysis) {
    els.trendChart.className = 'trend-chart empty-state';
    els.trendChart.innerHTML = '<div class="empty-copy">The chapter trend line will render here.</div>';
    return;
  }
  const metricId = state.selectedMetricId;
  const metric = METRICS.find((m) => m.id === metricId) || METRICS[0];
  const values = analysis.chapters.map((chapter) => chapter.metrics[metricId]);
  els.trendChart.className = 'trend-chart';
  els.trendChart.innerHTML = buildTrendSvg(values, metric);
}

function buildTrendSvg(values, metric) {
  const width = 920; const height = 268; const padX = 40; const padY = 32; const usableWidth = width - padX * 2; const usableHeight = height - padY * 2; const maxIndex = Math.max(values.length - 1, 1);
  const points = values.map((value, index) => ({ x: padX + usableWidth * (index / maxIndex), y: padY + usableHeight - ((value / 100) * usableHeight), value, index }));
  const path = points.map((point, index) => `${index === 0 ? 'M' : 'L'} ${point.x} ${point.y}`).join(' ');
  const fillPath = `${path} L ${points[points.length - 1].x} ${height - padY} L ${points[0].x} ${height - padY} Z`;
  const grid = [0, 25, 50, 75, 100].map((label) => { const y = padY + usableHeight - ((label / 100) * usableHeight); return `<g><line x1="${padX}" x2="${width - padX}" y1="${y}" y2="${y}" stroke="rgba(29,36,48,0.12)" /><text x="${padX - 8}" y="${y + 4}" text-anchor="end" font-size="11" fill="rgba(71,81,100,0.72)">${label}</text></g>`; }).join('');
  const circles = points.map((point) => `<circle cx="${point.x}" cy="${point.y}" r="4.5" fill="${metric.subjective ? 'rgba(96,116,155,0.95)' : 'rgba(43,122,120,0.95)'}"></circle>`).join('');
  const labels = points.map((point) => `<text x="${point.x}" y="${height - 10}" text-anchor="middle" font-size="11" fill="rgba(71,81,100,0.72)">${point.index + 1}</text>`).join('');
  return `
    <svg viewBox="0 0 ${width} ${height}" role="img" aria-label="${escapeHtml(metric.title)} by chapter">
      <defs><linearGradient id="trendFill" x1="0%" x2="0%" y1="0%" y2="100%"><stop offset="0%" stop-color="${metric.subjective ? 'rgba(96,116,155,0.3)' : 'rgba(43,122,120,0.28)'}"></stop><stop offset="100%" stop-color="rgba(255,255,255,0)"></stop></linearGradient></defs>
      ${grid}
      <path d="${fillPath}" fill="url(#trendFill)"></path>
      <path d="${path}" fill="none" stroke="${metric.subjective ? 'rgba(96,116,155,0.95)' : 'rgba(43,122,120,0.95)'}" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"></path>
      ${circles}
      ${labels}
      <text x="${width / 2}" y="18" fill="rgba(29,36,48,0.86)" font-size="14" text-anchor="middle">${escapeHtml(metric.title)} by chapter</text>
    </svg>
  `;
}

function renderFindings() {
  const analysis = state.analysis;
  if (!analysis) {
    els.findingsTitle.textContent = 'Metric findings';
    els.findingsSubtitle.textContent = 'Choose a metric to inspect the paragraphs and inline flags driving that score.';
    els.findingsMeta.textContent = '';
    els.highlightList.className = 'highlight-list empty-state';
    els.highlightList.innerHTML = '<div class="empty-copy">Nothing selected yet.</div>';
    return;
  }
  const metric = METRICS.find((item) => item.id === state.selectedMetricId) || METRICS[0];
  const highlights = getVisibleHighlights();
  const chapter = Number.isInteger(state.selectedChapterIndex) ? analysis.chapters[state.selectedChapterIndex] : null;
  els.findingsTitle.textContent = metric.title;
  els.findingsSubtitle.textContent = `${metric.lowLabel} → ${metric.highLabel}`;
  const overallScore = analysis.overall.metrics[metric.id];
  const confidence = analysis.overall.confidence[metric.id];
  const supportiveSignals = chapter ? (chapter.supportiveSignals?.[metric.id] || []) : (analysis.overall.supportiveSignals?.[metric.id] || []);
  els.findingsMeta.innerHTML = `${metric.includeInOverall ? 'Included in overall completeness.' : 'Excluded from overall completeness because it is more subjective.'} Overall score: <strong>${overallScore}%</strong> · Confidence: <strong>${confidence}%</strong>${chapter ? ` · Focused chapter: <strong>${chapter.index + 1}. ${escapeHtml(chapter.title)}</strong>` : ' · Showing all chapters.'}${supportiveSignals.length ? ` · Supportive signals: <strong>${supportiveSignals.map((signal) => escapeHtml(signal)).join('</strong>; <strong>')}</strong>` : ''}`;
  if (!highlights.length) {
    els.highlightList.className = 'highlight-list empty-state';
    els.highlightList.innerHTML = '<div class="empty-copy">No strong paragraph-level warnings were surfaced for this metric in the current scope.</div>';
    return;
  }
  els.highlightList.className = 'highlight-list';
  els.highlightList.innerHTML = highlights.slice(0, 30).map((issue) => `
    <article class="finding">
      <span class="tag">Chapter ${issue.chapterIndex + 1} · ${escapeHtml(issue.chapterTitle || analysis.chapters[issue.chapterIndex]?.title || '')}</span>
      <h3>${escapeHtml(issue.reason || 'Potential revision hotspot')}</h3>
      <div class="row"><span class="metric-chip">Severity ${(issue.severity * 100).toFixed(0)}%</span><span class="metric-chip ${metric.subjective ? 'subjective' : ''}">${metric.title}</span></div>
      ${issue.fragments?.length ? `<div class="inline-preview">${issue.fragments.slice(0, 3).map((fragment) => `<span class="inline-snippet">${escapeHtml(truncate(issue.excerpt.slice(fragment.start, fragment.end), 72))}</span>`).join('')}</div>` : ''}
      <p>${escapeHtml(truncate(issue.excerpt, 280))}</p>
      <button type="button" class="ghost" data-jump="${issue.paragraphId}">Jump to paragraph</button>
    </article>
  `).join('');
  els.highlightList.querySelectorAll('[data-jump]').forEach((button) => { button.addEventListener('click', () => jumpToParagraph(button.dataset.jump)); });
}

function getVisibleHighlights() {
  const analysis = state.analysis;
  if (!analysis) return [];
  const metricId = state.selectedMetricId;
  return Number.isInteger(state.selectedChapterIndex) ? analysis.chapters[state.selectedChapterIndex].issueMap[metricId] : analysis.overall.allHighlights[metricId];
}

function renderManuscript() {
  const analysis = state.analysis;
  if (!analysis) {
    els.manuscriptMeta.textContent = '';
    els.manuscriptView.className = 'manuscript-view empty-state';
    els.manuscriptView.innerHTML = '<div class="empty-copy">Detected chapters and inline annotations will render here after analysis.</div>';
    return;
  }
  const metricId = state.selectedMetricId;
  const metric = METRICS.find((m) => m.id === metricId) || METRICS[0];
  els.manuscriptMeta.innerHTML = `Viewing <strong>${escapeHtml(metric.title)}</strong> highlights. Colored paragraphs show where revision pressure is strongest for the selected metric, and the inline marks show the exact phrases or sentences the engine used as evidence.`;
  const chapters = Number.isInteger(state.selectedChapterIndex) ? [analysis.chapters[state.selectedChapterIndex]] : analysis.chapters;
  els.manuscriptView.className = 'manuscript-view';
  els.manuscriptView.innerHTML = chapters.map((chapter) => `
    <section class="chapter-block" id="chapter-${chapter.index + 1}">
      <header>
        <div><div class="chapter-mini">Chapter ${chapter.index + 1} · ${chapter.wordCount.toLocaleString()} words · completeness ${chapter.completeness}%</div><h3>${escapeHtml(chapter.title)}</h3></div>
        <div class="metric-chip ${metric.subjective ? 'subjective' : ''}">${metric.title}: ${chapter.metrics[metricId]}%</div>
      </header>
      ${chapter.paragraphs.map((paragraph) => paragraphHtml(paragraph, metricId)).join('')}
    </section>
  `).join('');
}

function paragraphHtml(paragraph, metricId) {
  const issue = paragraph.issues[metricId];
  const severityClass = !issue ? '' : issue.severity >= 0.68 ? 'severity-strong' : issue.severity >= 0.42 ? 'severity-medium' : 'severity-light';
  const content = issue ? annotateTextWithIssue(paragraph.text, issue) : escapeHtml(paragraph.text);
  return `<p class="manuscript-paragraph ${severityClass}" id="${paragraph.id}" title="${escapeHtml(issue?.reason || '')}"><span class="paragraph-anchor">¶</span>${content}</p>`;
}

function annotateTextWithIssue(text, issue) {
  const fragments = normalizeFragments(issue?.fragments || [], text);
  if (!fragments.length) return escapeHtml(text);
  let html = '';
  let cursor = 0;
  const levelClass = issue.severity >= 0.68 ? 'strong' : issue.severity >= 0.42 ? 'medium' : 'light';
  fragments.forEach((fragment) => {
    const start = clamp(fragment.start, 0, text.length);
    const end = clamp(fragment.end, start, text.length);
    if (start > cursor) html += escapeHtml(text.slice(cursor, start));
    html += `<mark class="inline-mark ${levelClass}" title="${escapeHtml(fragment.label || issue.reason || '')}">${escapeHtml(text.slice(start, end))}</mark>`;
    cursor = end;
  });
  if (cursor < text.length) html += escapeHtml(text.slice(cursor));
  return html;
}

function jumpToParagraph(paragraphId) {
  const node = document.getElementById(paragraphId);
  if (!node) return;
  node.scrollIntoView({ behavior: 'smooth', block: 'center' });
  node.animate([{ boxShadow: '0 0 0 0 rgba(96,116,155,0)' }, { boxShadow: '0 0 0 5px rgba(96,116,155,0.45)' }, { boxShadow: '0 0 0 0 rgba(96,116,155,0)' }], { duration: 1100, easing: 'ease-out' });
}

function evaluateVoiceConsistency(text, quoteSamples, global) {
  if (!quoteSamples.length) return 0.6;
  const attributed = quoteSamples.filter((sample) => sample.speaker && global.characterMap.has(sample.speaker));
  if (!attributed.length) return clamp(0.46 + quoteSamples.length * 0.04, 0.46, 0.62);
  const scores = attributed.map((sample) => {
    const profile = global.characterMap.get(sample.speaker);
    if (!profile || profile.quoteCount < 2 || !profile.quotes.length) return 0.66;
    const localWords = countWords(sample.content);
    const avgQuoteWords = average(profile.quotes);
    const lengthDeviation = Math.abs(localWords - avgQuoteWords) / Math.max(avgQuoteWords, 5);
    const profileQuoteCount = Math.max(profile.quoteCount, 1);
    const punctuationDiff =
      Math.abs((sample.text.includes('?') ? 1 : 0) - safeRatio(profile.punctuation.q, profileQuoteCount)) * 0.12 +
      Math.abs((sample.text.includes('!') ? 1 : 0) - safeRatio(profile.punctuation.ex, profileQuoteCount)) * 0.1 +
      Math.abs((sample.text.includes('...') ? 1 : 0) - safeRatio(profile.punctuation.ellipsis, profileQuoteCount)) * 0.08;
    const localContraction = /(?:[A-Za-z]+n't|[A-Za-z]+'(?:re|ve|ll|d|m|s))/.test(sample.content) ? 1 : 0;
    const localShort = localWords <= 6 ? 1 : 0;
    const localLong = localWords >= 20 ? 1 : 0;
    const styleDiff =
      Math.abs(localContraction - safeRatio(profile.contractions, profileQuoteCount)) * 0.16 +
      Math.abs(localShort - safeRatio(profile.shortQuotes, profileQuoteCount)) * 0.14 +
      Math.abs(localLong - safeRatio(profile.longQuotes, profileQuoteCount)) * 0.12;
    return clamp(0.92 - lengthDeviation * 0.42 - punctuationDiff - styleDiff, 0.16, 0.95);
  });
  return average(scores);
}

function splitSentencesWithOffsets(text) {
  const regex = /[^.!?]+(?:[.!?]+|$)/g;
  const matches = [];
  let match;
  while ((match = regex.exec(text))) {
    const raw = match[0];
    const trimmed = raw.trim();
    if (!trimmed) continue;
    const leading = raw.indexOf(trimmed);
    const start = match.index + Math.max(leading, 0);
    const end = start + trimmed.length;
    matches.push({ text: trimmed, start, end });
  }
  if (!matches.length && text.trim()) {
    const trimmed = text.trim();
    const start = text.indexOf(trimmed);
    matches.push({ text: trimmed, start, end: start + trimmed.length });
  }
  return matches;
}

function findRegexRanges(text, regex, label) {
  const flags = regex.flags.includes('g') ? regex.flags : `${regex.flags}g`;
  const source = new RegExp(regex.source, flags);
  const results = [];
  let match;
  while ((match = source.exec(text))) {
    results.push({ start: match.index, end: match.index + match[0].length, label });
    if (match[0].length === 0) source.lastIndex += 1;
  }
  return results;
}

function findPhraseRanges(text, phrases, label) {
  const lower = text.toLowerCase();
  const found = [];
  phrases.forEach((phrase) => {
    const target = String(phrase).toLowerCase();
    let fromIndex = 0;
    while (fromIndex < lower.length) {
      const hit = lower.indexOf(target, fromIndex);
      if (hit === -1) break;
      found.push({ start: hit, end: hit + target.length, label });
      fromIndex = hit + target.length;
    }
  });
  return found;
}

function findQuoteRanges(text, label) { return findRegexRanges(text, /["“][^"”]{2,}["”]/g, label); }
function findLexiconRanges(text, lexicon, label) {
  const words = [...new Set(lexicon)].filter(Boolean).sort((a, b) => b.length - a.length);
  if (!words.length) return [];
  const regex = new RegExp(`\\b(?:${words.map((word) => escapeRegex(word)).join('|')})\\b`, 'gi');
  return findRegexRanges(text, regex, label);
}
function findCapitalizedNameRanges(text, label) { return findRegexRanges(text, /\b[A-Z][a-z]{2,}\b/g, label).filter((range) => !STOP_CAPITALIZED.has(text.slice(range.start, range.end))); }
function findRepeatedWordRanges(text, label) { return findRegexRanges(text, /\b(\w+)\s+\1\b/gi, label); }

function normalizeFragments(fragments, text) {
  const sorted = fragments.filter((fragment) => fragment && Number.isFinite(fragment.start) && Number.isFinite(fragment.end) && fragment.end > fragment.start).map((fragment) => ({ start: clamp(Math.round(fragment.start), 0, text.length), end: clamp(Math.round(fragment.end), 0, text.length), label: fragment.label || 'Flagged text' })).filter((fragment) => fragment.end > fragment.start).sort((a, b) => a.start - b.start || a.end - b.end);
  const merged = [];
  sorted.forEach((fragment) => {
    const last = merged[merged.length - 1];
    if (!last || fragment.start > last.end) { merged.push(fragment); return; }
    if (fragment.end > last.end) last.end = fragment.end;
    if ((fragment.label || '').length > (last.label || '').length) last.label = fragment.label;
  });
  return merged.slice(0, 4);
}

function countCapitalizedNames(text) { return findCapitalizedNameRanges(text, 'Character reference').length; }
function countLexiconHits(words, lexicon) { const set = new Set(lexicon); return words.reduce((sumValue, word) => sumValue + (set.has(word) ? 1 : 0), 0); }
function countPhraseHits(lowerText, phrases) { return phrases.reduce((sumValue, phrase) => sumValue + (lowerText.includes(String(phrase).toLowerCase()) ? 1 : 0), 0); }
function tokenizeWords(text) { return (text.toLowerCase().match(/[a-zA-Z']+/g) || []).map((word) => word.replace(/^'+|'+$/g, '')); }
function countWords(text) { return tokenizeWords(text).length; }
function repeatedWordRate(text) {
  const words = tokenizeWords(text);
  if (!words.length) return 0;
  const counts = new Map();
  words.forEach((word) => counts.set(word, (counts.get(word) || 0) + 1));
  const repeated = [...counts.values()].filter((count) => count > 2).reduce((acc, count) => acc + count, 0);
  return repeated / words.length;
}
function averageSeverity(issues) { return issues.length ? average(issues.slice(0, 5).map((issue) => issue.severity)) : 0; }
function mapValues(object, mapper) { const next = {}; Object.keys(object).forEach((key) => { next[key] = mapper(object[key], key); }); return next; }
function safeRatio(numerator, denominator) { if (!denominator) return 0; return clamp(numerator / denominator, 0, 1.5); }
function average(numbers) { const valid = numbers.filter((value) => Number.isFinite(value)); return valid.length ? valid.reduce((sumValue, value) => sumValue + value, 0) / valid.length : 0; }
function weightedAverage(entries) { let total = 0; let totalWeight = 0; entries.forEach(([value, weight]) => { if (!Number.isFinite(value) || !Number.isFinite(weight) || weight <= 0) return; total += value * weight; totalWeight += weight; }); return totalWeight ? total / totalWeight : 0; }
function sum(numbers) { return numbers.reduce((total, number) => total + number, 0); }
function median(numbers) { const valid = numbers.filter((value) => Number.isFinite(value)).slice().sort((a, b) => a - b); if (!valid.length) return 0; const mid = Math.floor(valid.length / 2); return valid.length % 2 ? valid[mid] : (valid[mid - 1] + valid[mid]) / 2; }
function clamp(value, min, max) { return Math.min(max, Math.max(min, value)); }
function shortMetricTitle(title) { return title.replace('Natural and Engaging ', '').replace('Excellent ', '').replace('Heart-Wrenching or ', '').replace(' and Thought-Provoking', ''); }
function heatmapColor(score, subjective) { if (subjective) { if (score < 40) return 'rgba(96,116,155,0.2)'; if (score < 70) return 'rgba(96,116,155,0.28)'; return 'rgba(96,116,155,0.38)'; } if (score < 40) return 'rgba(162,72,86,0.22)'; if (score < 70) return 'rgba(173,123,44,0.22)'; return 'rgba(76,122,91,0.22)'; }
function barGradient(score, subjective) { if (subjective) return 'linear-gradient(90deg, rgba(96,116,155,0.22), rgba(96,116,155,0.4))'; if (score < 40) return 'linear-gradient(90deg, rgba(162,72,86,0.22), rgba(162,72,86,0.38))'; if (score < 70) return 'linear-gradient(90deg, rgba(173,123,44,0.22), rgba(173,123,44,0.38))'; return 'linear-gradient(90deg, rgba(76,122,91,0.22), rgba(76,122,91,0.38))'; }
function summarizeReasons(reasonParts) { const filtered = reasonParts.filter(Boolean); return filtered.length ? filtered.join(' · ') : 'Potential revision hotspot'; }
function setStatus(message, mode = 'idle') { els.statusBox.className = `status ${mode}`; els.statusBox.textContent = message; }
function setWorking(isWorking) { els.analyzeBtn.disabled = isWorking; els.loadSampleBtn.disabled = isWorking; }
function escapeHtml(value) { return String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;'); }
function truncate(text, length) { return text.length <= length ? text : `${text.slice(0, length - 1).trimEnd()}…`; }
function formatNumber(value) { return Number(value || 0).toLocaleString(); }
function escapeRegex(value) { return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
function nextFrame() { return new Promise((resolve) => requestAnimationFrame(() => resolve())); }

function getSampleManuscript() {
  return `CHAPTER ONE

Mara found the key in a teacup, which was the sort of thing that only happened in her grandmother's kitchen and nowhere else in the valley. Rain needled the windows. The stove clicked and breathed. Somewhere above the ceiling, the old house gave a small wooden sigh.

"You look like the storm insulted your mother," Gran said.

"It insulted the whole mountain," Mara said. "The bridge is gone. Or mostly gone. There are planks in the river now."

Gran did not turn. She kept shaving orange peel into the kettle as if bridges washed away every Tuesday. "Then the mountain wants something."

Mara hated it when Gran talked like that. The valley always wanted something in her stories. The frost wanted patience. The crows wanted names. The river wanted blood or songs or sometimes both. The actual valley mostly wanted repairs.

On the table, beside the chipped sugar bowl, sat a brass key slick with tea. Mara had never seen it before. It was long, dark, and cold enough to look wet.

"Whose is that?" she asked.

Gran finally turned, and something in her face seemed to go still. "It should not be here."

CHAPTER TWO

By noon, the whole village smelled of split pine and river mud. Men shouted over the torn bridge. Children balanced on the safe side of the bank and watched like they had paid for tickets. Mara threaded through them with the key in her coat pocket, her heartbeat tapping against the metal.

Elias caught up to her by the post office, breathless and grinning as usual. "Tell me that face means trouble and not chores."

"What if it's both?"

"Then I am deeply interested."

He always spoke as if the world were leaning in to hear the punch line. Even now, with mud on his boots and half the village swearing at the river, his voice carried a ridiculous brightness.

Mara showed him the key. He whistled. "That is villain-shaped."

"Gran says it shouldn't exist."

"That is, somehow, even better."

She wanted to laugh, but the bridge groaned behind them with a sound like an animal in pain. The villagers went quiet. A final beam slipped free and vanished under the boiling brown water.

Elias did not grin then. He looked at the river, and for a moment he seemed much older than nineteen. "My brother's still on the far ridge," he said softly.

CHAPTER THREE

Gran kept the forbidden map in the flour bin, because apparently secrecy and baking were cousins. The map showed tunnels under the mountain, all of them branching toward a chamber marked only with an eye and a crown. Mara spread the paper flat while Elias paced the pantry and muttered that none of this was normal.

"You say that every ten minutes," Mara said.

"Because every ten minutes something new becomes deeply abnormal."

Gran leaned on the doorway. "There are old locks in this valley," she said. "Older than the village. Older than my family. Some were made to keep things out. Some were made to keep bargains in."

"That is not a sentence people enjoy hearing," Elias said.

Mara traced the crown with one finger. The ink had bled outward in tiny black veins. It made her think of winter roots under frozen soil. "What happens if the wrong door opens?"

Gran's silence lasted too long.

Then she said, very gently, "We find out how much the valley remembers about mercy."`;
}

init();
