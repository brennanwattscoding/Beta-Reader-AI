# Beta Reader AI

Beta Reader AI is a browser-based manuscript diagnostic prototype for authors.

## What it does

- Reads `.txt` and `.docx` manuscripts entirely in the browser
- Splits the manuscript into chapters or fallback sections
- Scores each chapter and the full manuscript across 13 metrics
- Excludes more subjective metrics from the overall completeness score
- Shows a heatmap, bar-style dashboard, trend chart, and clickable findings list
- Highlights likely problem paragraphs for the selected metric
- Keeps the analysis local in the browser and does not save the manuscript

## What it is not

This is a local heuristic / AI-style diagnostic, not a full language-model critique.

The percentages are intended as revision-pressure indicators, not objective measures of literary quality. The subjective metrics are confidence-gated so weak evidence is pulled closer to neutral instead of being overstated.

## Metrics included

- Easy to Understand
- Perfect Pace
- Well Written Characters
- Very Creative
- Natural and Engaging Dialogue
- Strong Plot
- Vivid and Immersive Setting
- Excellent Grammar & Style
- Hooking Opening
- Surprising Twists
- Deep and Thought-Provoking Themes
- Heart-Wrenching or Moving
- Consistently In Character

## Privacy model

- No manuscript uploads
- No analytics
- No localStorage
- No fetch/XHR calls for manuscript content
- Restrictive Content Security Policy with `connect-src 'none'`
- Local `.docx` extraction powered by a bundled browser copy of JSZip and an in-browser XML text extractor

## How to use

1. Open `index.html` in a browser.
2. Upload a `.txt` or `.docx` manuscript.
3. Set genre, demographic, draft stage, and manuscript completion percentage.
4. Click **Analyze manuscript**.
5. Click metric bars or heatmap cells to inspect highlighted paragraphs.

## Notes for GitHub

This repo is ready as a v1 prototype. It is best presented as a private, browser-only manuscript diagnostic with heuristic analysis rather than as a full editorial AI.

## Third-party library

- `libs/jszip.min.js` is included for local `.docx` reading.
- See `libs/JSZIP-LICENSE.txt` for the bundled JSZip license.
